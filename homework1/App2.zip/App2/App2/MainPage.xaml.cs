﻿using System;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Popups;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Xaml.Navigation;
using System.Threading;
using System.Linq;
// https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x804 上介绍了“空白页”项模板

namespace App2
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        string eMessage = "";
        public TaskListViewModel ViewModel { get; set; }
        public MainPage()
        {
            this.InitializeComponent();
            this.ViewModel = App.viewModel;
            if (Window.Current.Bounds.Width > 600)
            {
                width.Width = 700;
            }
            else
            {
                width.Width = 500;
            }
        }
        private void Page_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (Window.Current.Bounds.Width > 600)
            {
                width.Width = 700;
            }
            else
            {
                width.Width = 500;
            }
        }
        private async void test(int temp)
        {
            var messageDialog = new MessageDialog("" + temp);
            await messageDialog.ShowAsync();
        }

        private void NavigateButton_Click(object sender, RoutedEventArgs e)
        {
            int index = -1;
            Frame.Navigate(typeof(BlankPage1), index);
        }

        private async void ChooseImageButton_Click(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail;
            picker.SuggestedStartLocation =
                Windows.Storage.Pickers.PickerLocationId.ComputerFolder;
            picker.FileTypeFilter.Add(".jpg");
            picker.FileTypeFilter.Add(".jpeg");
            picker.FileTypeFilter.Add(".png");

            Windows.Storage.StorageFile file = await picker.PickSingleFileAsync();
            if (file != null)
            {
                using (IRandomAccessStream fileStream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read))
                {
                    // Set the image source to the selected bitmap 
                    BitmapImage bitmapImage = new BitmapImage();
                    await bitmapImage.SetSourceAsync(fileStream);
                    photo.Source = bitmapImage;
                }
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private async void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            eMessage = "";

            if (title.Text == "")
            {
                eMessage += "title should not be empty!\n";
            }

            if (detail.Text == "")
            {
                eMessage += "detail should not be empty!\n";
            }

            if (DateTime.Now.Year == date.Date.DateTime.Year && DateTime.Now.Month == date.Date.DateTime.Month && DateTime.Now.Day == date.Date.DateTime.Day)
            {
            }
            else if (DateTime.Compare(DateTime.Now, date.Date.DateTime) > 0)
            {
                eMessage += "the due date has passed!\n";
            }
            
            if(importance.SelectedIndex == -1)
            {
                eMessage += "the importance should not be empty";
            }

            if (eMessage == "")
            {
                eMessage = "you have created a new task successfully!";
                var temp = eMessage;
            }

            // Create the message dialog and set its content
            var messageDialog = new MessageDialog(eMessage);

            if (eMessage == "you have created a new task successfully!")
            {
                messageDialog.Commands.Add(new UICommand(
                                "OK",
                                new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;
                ViewModel.AddTaskItem(title.Text, detail.Text, importance.SelectedIndex, date.Date.DateTime);
                MyListView.SelectedIndex = -1;
                title.Text = "";
                detail.Text = "";
                date.Date = DateTime.Now;
                importance.SelectedIndex = -1;
                // MyListView.SelectedIndex = ViewModel.TaskItems.Count();
            }
            else
            {
                // Add commands and set their callbacks; both buttons use the same callback function instead of inline event handlers
                messageDialog.Commands.Add(new UICommand(
                    "Try again",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));
                messageDialog.Commands.Add(new UICommand(
                    "Close",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;

                // Set the command to be invoked when escape is pressed
                messageDialog.CancelCommandIndex = 1;
            }

            // Show the message dialog
            await messageDialog.ShowAsync();
        }

        private void CommandInvokedHandler(IUICommand command)
        {
        }

        private void title_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void detail_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            createButton.Content = "create";
            createButton.Click -= UpdateButton_Click;
            createButton.Click -= CreateButton_Click;
            createButton.Click += CreateButton_Click;
            MyListView.SelectedIndex = -1;
            title.Text = "";
            detail.Text = "";
            date.Date = DateTime.Now;
            importance.SelectedIndex = -1;
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            int index = MyListView.SelectedIndex;
            ViewModel.DeleteTaskItem(index);
            createButton.Content = "create";
            createButton.Click -= UpdateButton_Click;
            createButton.Click -= CreateButton_Click;
            createButton.Click += CreateButton_Click;
            MyListView.SelectedIndex = -1;
            title.Text = "";
            detail.Text = "";
            date.Date = DateTime.Now;
            importance.SelectedIndex = -1;
            var messageDialog = new MessageDialog("you have deleted the task successfully!");
            messageDialog.Commands.Add(new UICommand(
                                "OK",
                                new UICommandInvokedHandler(this.CommandInvokedHandler)));
            await messageDialog.ShowAsync();
        }

        private async void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            eMessage = "";

            if (title.Text == "")
            {
                eMessage += "title should not be empty!\n";
            }

            if (detail.Text == "")
            {
                eMessage += "detail should not be empty!\n";
            }

            if (DateTime.Now.Year == date.Date.DateTime.Year && DateTime.Now.Month == date.Date.DateTime.Month && DateTime.Now.Day == date.Date.DateTime.Day)
            {
            }
            else if (DateTime.Compare(DateTime.Now, date.Date.DateTime) > 0)
            {
                eMessage += "the due date has passed!\n";
            }

            if (eMessage == "")
            {
                eMessage = "you have updated the task successfully!";
            }

            // Create the message dialog and set its content
            var messageDialog = new MessageDialog(eMessage);

            if (eMessage == "you have updated the task successfully!")
            {
                messageDialog.Commands.Add(new UICommand(
                                "OK",
                                new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;
                ViewModel.UpdateList(MyListView.SelectedIndex, title.Text, detail.Text, importance.SelectedIndex, date.Date.DateTime);
                //ViewModel.OnPropertyChanged("");
                //this.Bindings.Update();
                createButton.Content = "create";
                createButton.Click -= UpdateButton_Click;
                createButton.Click -= CreateButton_Click;
                createButton.Click += CreateButton_Click;
                MyListView.SelectedIndex = -1;
                title.Text = "";
                detail.Text = "";
                date.Date = DateTime.Now;
                importance.SelectedIndex = -1;
                //Frame.Navigate(typeof(MainPage));
            }
            else
            {
                // Add commands and set their callbacks; both buttons use the same callback function instead of inline event handlers
                messageDialog.Commands.Add(new UICommand(
                    "Try again",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));
                messageDialog.Commands.Add(new UICommand(
                    "Close",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;

                // Set the command to be invoked when escape is pressed
                messageDialog.CancelCommandIndex = 1;
            }

            // Show the message dialog
            await messageDialog.ShowAsync();
        }

        private async void Update_Click(object sender, ItemClickEventArgs e)
        {
            /*            
                        int index = MyListView.SelectedIndex;
                        var messageDialog = new MessageDialog("" + index);
                        if (index != -1)
                        {
                            await messageDialog.ShowAsync();
                        }
                    }*/
            
            await System.Threading.Tasks.Task.Delay(100);
            int index = MyListView.SelectedIndex;
            if (Window.Current.Bounds.Width < 1000)
            {
                Frame.Navigate(typeof(BlankPage1), index);
            }//需要跳转
            else
            {
                if (index!=-1)
                {
                    title.Text = ViewModel.TaskItems[index].Title;
                    detail.Text = ViewModel.TaskItems[index].Detail;
                    importance.SelectedIndex = ViewModel.TaskItems[index].Importance;
                    date.Date = ViewModel.TaskItems[index].DueTime;
                }
                createButton.Content = "update";
                createButton.Click -= CreateButton_Click;
                createButton.Click -= UpdateButton_Click;
                createButton.Click += UpdateButton_Click;
            }//不需要跳转
        }
    }
}