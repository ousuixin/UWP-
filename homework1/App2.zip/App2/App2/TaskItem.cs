﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using App2.Common;
using Windows.UI;
using Windows.UI.Xaml.Media;

namespace App2
{
    public class TaskItem: INotifyPropertyChanged
    {
        private bool isChecked { get; set; }
        private string title { get; set; }
        private string detail { get; set; }
        private int importance { get; set; }
        private DateTimeOffset dueTime { get; set; }

        public bool IsChecked
        {
            get { return this.isChecked; }
            set {
                isChecked = value;
                OnPropertyChanged();
            }
        }

        public string Title
        {
            get { return this.title; }
            set
            {
                title= value;
                OnPropertyChanged();
            }
        }

        public int Importance
        {
            get { return importance; }
            set
            {
                importance = value;
                OnPropertyChanged();
            }
        }

        public string Detail
        {
            get { return this.detail; }
            set
            {
                detail = value;
                OnPropertyChanged();
            }
        }

        public DateTimeOffset DueTime
        {
            get { return dueTime; }
            set
            {
                dueTime = value;
                OnPropertyChanged();
            }
        }

        public TaskItem()
        {
            this.isChecked = false;
            this.title = "";
            this.detail = "";
            this.importance = 0;
            this.dueTime = new DateTime(2018, 3, 30);
        }

        public TaskItem(string Title, string Detail, int Importance, DateTime DueTime)
        {
            this.isChecked = false;
            this.title = Title;
            this.detail = Detail;
            this.importance = Importance;
            this.dueTime = DueTime;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged([CallerMemberName]string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    public class TaskListViewModel
    {
        private ObservableCollection<TaskItem> taskItems = new ObservableCollection<TaskItem>();
        public ObservableCollection<TaskItem> TaskItems { get { return this.taskItems; } }
        public TaskListViewModel()
        {
            this.taskItems.Add(new TaskItem("Watch movie", "Watch movie with roommate", 1, new DateTime(2018, 3, 30)));
            this.taskItems.Add(new TaskItem("Play game", "Play computer games with roommate", 2, new DateTime(2018, 3, 31)));
        }
        public void AddTaskItem(string Title, string Detail, int Importance, DateTime DueTime)
        {
            this.taskItems.Add(new TaskItem(Title, Detail, Importance, DueTime));
        }
        public void DeleteTaskItem(int index)
        {
            this.taskItems.RemoveAt(index);

        }
        public void UpdateList(int index, string Title, string Detail, int Importance, DateTime DueTime)
        {

            //this.taskItems.RemoveAt(index);
            //this.taskItems.Insert(index, new TaskItem(Title, Detail, Importance, DueTime));
            taskItems[index].Title = Title;
            taskItems[index].Detail = Detail;
            taskItems[index].DueTime = DueTime;
            taskItems[index].Importance = Importance;
            //taskItems.Move(index, index);
        }
    }

    public class boolToVisibleConverter: Windows.UI.Xaml.Data.IValueConverter
    {
        public object Convert(object value, Type targetType,
        object parameter, string language)
        {
            Windows.UI.Xaml.Visibility visibility = Windows.UI.Xaml.Visibility.Collapsed;
            // value is the data from the source object.
            Boolean thisbool = (Boolean)value;
            if(thisbool==true)
            {
                visibility = Windows.UI.Xaml.Visibility.Visible;
                return visibility;
            }
            // Return the value to pass to the target.
            return visibility;
        }

        // ConvertBack is not implemented for a OneWay binding.
        public object ConvertBack(object value, Type targetType,
            object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
    public class boolToBoolConverter : Windows.UI.Xaml.Data.IValueConverter
    {
        public object Convert(object value, Type targetType,
        object parameter, string language)
        {
            // value is the data from the source object.
            Boolean thisbool = (Boolean)value;
            if (thisbool == true)
            {
                return true;
            }
            // Return the value to pass to the target.
            return false;
        }

        // ConvertBack is not implemented for a OneWay binding.
        public object ConvertBack(object value, Type targetType,
            object parameter, string language)
        {
            // value is the data from the source object.
            Boolean thisbool = (Boolean)value;
            if (thisbool == true)
            {
                return true;
            }
            // Return the value to pass to the target.
            return false;
        }
    }

    public class widthToVisibleConverter : Windows.UI.Xaml.Data.IValueConverter
    {
        public object Convert(object value, Type targetType,
        object parameter, string language)
        {
            Windows.UI.Xaml.Visibility visibility = Windows.UI.Xaml.Visibility.Collapsed;
            // value is the data from the source object.
            double thisbool = (double)value;
            if (thisbool > 600)
            {
                visibility = Windows.UI.Xaml.Visibility.Visible;
                return visibility;
            }
            // Return the value to pass to the target.
            return visibility;
        }

        // ConvertBack is not implemented for a OneWay binding.
        public object ConvertBack(object value, Type targetType,
            object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
        public class importanceToColor : Windows.UI.Xaml.Data.IValueConverter
    {
        public object Convert(object value, Type targetType,
        object parameter, string language)
        {
            // value is the data from the source object.
            int color = (int)value;
            SolidColorBrush red = new SolidColorBrush(Colors.IndianRed);
            SolidColorBrush orange = new SolidColorBrush(Colors.Orange);
            SolidColorBrush green = new SolidColorBrush(Colors.LightGreen);
            SolidColorBrush blue = new SolidColorBrush(Colors.SkyBlue);
            if (color == 0)
            {
                return red;
            }
            else if (color ==1)
            {
                return orange;
            } else if (color ==2)
            {
                return green; 
            }
            else
            {
                return blue;
            }
        }

        // ConvertBack is not implemented for a OneWay binding.
        public object ConvertBack(object value, Type targetType,
            object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
    
}