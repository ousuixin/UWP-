﻿using Windows.UI.Popups;
using Windows.Storage.Streams;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Core;
using Windows.Storage;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

namespace App2
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    /// 

    public sealed partial class BlankPage1 : Page
    {
        public TaskListViewModel ViewModel { get; set; }
        string eMessage = "";
        int index = -1;

        public BlankPage1()
        {
            this.InitializeComponent();
            this.ViewModel = App.viewModel;
        }

        private async void UpdateButton_Click (object sender, RoutedEventArgs e)
        {
            eMessage = "";

            if (title.Text == "")
            {
                eMessage += "title should not be empty!\n";
            }

            if (detail.Text == "")
            {
                eMessage += "detail should not be empty!\n";
            }

            if (DateTime.Now.Year == date.Date.DateTime.Year && DateTime.Now.Month == date.Date.DateTime.Month && DateTime.Now.Day == date.Date.DateTime.Day)
            {
            }
            else if (DateTime.Compare(DateTime.Now, date.Date.DateTime) > 0)
            {
                eMessage += "the due date has passed!\n";
            }

            if (eMessage == "")
            {
                eMessage = "you have updated the task successfully!";
            }

            // Create the message dialog and set its content
            var messageDialog = new MessageDialog(eMessage);

            if (eMessage == "you have updated the task successfully!")
            {
                messageDialog.Commands.Add(new UICommand(
                                "OK",
                                new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;
                ViewModel.UpdateList(index, title.Text, detail.Text, importance.SelectedIndex, date.Date.DateTime);
                Frame.GoBack();
            }
            else
            {
                // Add commands and set their callbacks; both buttons use the same callback function instead of inline event handlers
                messageDialog.Commands.Add(new UICommand(
                    "Try again",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));
                messageDialog.Commands.Add(new UICommand(
                    "Close",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;

                // Set the command to be invoked when escape is pressed
                messageDialog.CancelCommandIndex = 1;
            }

            // Show the message dialog
            await messageDialog.ShowAsync();
        }

        private void ReductionButton_Click(object sender, RoutedEventArgs e)
        {
            title.Text = ViewModel.TaskItems.ElementAt(index).Title;
            detail.Text = ViewModel.TaskItems.ElementAt(index).Detail;
            date.Date = ViewModel.TaskItems.ElementAt(index).DueTime;
            importance.SelectedIndex = ViewModel.TaskItems.ElementAt(index).Importance;
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            index = (int)e.Parameter;
            if (index != -1)
            {
                title.Text = ViewModel.TaskItems.ElementAt(index).Title;
                detail.Text = ViewModel.TaskItems.ElementAt(index).Detail;
                date.Date = ViewModel.TaskItems.ElementAt(index).DueTime;
                importance.SelectedIndex = ViewModel.TaskItems.ElementAt(index).Importance;

                CreateButton.Content = "update";
                CreateButton.Click -= CreateButton_Click;
                CreateButton.Click += UpdateButton_Click;
                CancelButton.Click -= CancelButton_Click;
                CancelButton.Click += ReductionButton_Click;
            }//点击todoitem传递过来的
        }

        /*
                private void AppBarButton_Click(object sender, RoutedEventArgs e)
                {
                    Frame.GoBack();
                }
        */
        private async void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            eMessage = "";

            if (title.Text=="")
            {
                eMessage += "title should not be empty!\n";
            }

            if (detail.Text=="")
            {
                eMessage += "detail should not be empty!\n";
            }

            if (DateTime.Now.Year == date.Date.DateTime.Year&&DateTime.Now.Month == date.Date.DateTime.Month&&DateTime.Now.Day == date.Date.DateTime.Day)
            {
            } else if (DateTime.Compare(DateTime.Now, date.Date.DateTime) > 0)
            {
                eMessage += "the due date has passed!\n";
            }

            if (eMessage == "")
            {
                eMessage = "you have created a new task successfully!";
            }

            // Create the message dialog and set its content
            var messageDialog = new MessageDialog(eMessage);

            if (eMessage == "you have created a new task successfully!")
            {
                messageDialog.Commands.Add(new UICommand(
                                "OK",
                                new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;
                ViewModel.AddTaskItem(title.Text, detail.Text, importance.SelectedIndex, date.Date.DateTime);
                Frame.GoBack();
            }
            else
            {
                // Add commands and set their callbacks; both buttons use the same callback function instead of inline event handlers
                messageDialog.Commands.Add(new UICommand(
                    "Try again",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));
                messageDialog.Commands.Add(new UICommand(
                    "Close",
                    new UICommandInvokedHandler(this.CommandInvokedHandler)));

                // Set the command that will be invoked by default
                messageDialog.DefaultCommandIndex = 0;

                // Set the command to be invoked when escape is pressed
                messageDialog.CancelCommandIndex = 1;
            }

            // Show the message dialog
            await messageDialog.ShowAsync();
        }

        private void CommandInvokedHandler(IUICommand command)
        {
        }

        private void title_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void detail_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            title.Text = "";
            detail.Text = "";
            date.Date = DateTime.Now;
        }

        private async void ChooseImageButton_Click(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail;
            picker.SuggestedStartLocation =
                Windows.Storage.Pickers.PickerLocationId.ComputerFolder;
            picker.FileTypeFilter.Add(".jpg");
            picker.FileTypeFilter.Add(".jpeg");
            picker.FileTypeFilter.Add(".png");

            Windows.Storage.StorageFile file = await picker.PickSingleFileAsync();
            if (file != null)
            {
                using (IRandomAccessStream fileStream = await file.OpenAsync(Windows.Storage.FileAccessMode.Read))
                {
                    // Set the image source to the selected bitmap 
                    BitmapImage bitmapImage = new BitmapImage();
                    await bitmapImage.SetSourceAsync(fileStream);
                    photo.Source = bitmapImage;
                }
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
